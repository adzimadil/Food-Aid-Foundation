<?php
$_GET['sname'];
session_start();
$search = $_POST['search'];

$servername = "localhost";
$username = "root";
$password = "";
$db = "fadatabase";

$conn = new mysqli($servername, $username, $password, $db);

if ($conn->connect_error){
	die("Connection failed: ". $conn->connect_error);
}

$sql = "SELECT * FROM tblbank WHERE (name = '" . $_GET['sname'] . "') ORDER BY name ASC;";

$result = $conn->query($sql);

?>

<!DOCTYPE html>
<html>
<head>
	<title>Food Aid Foundation</title>
    <link rel="stylesheet" href="fstyle.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css" integrity="sha512-SzlrxWUlpfuzQ+pcUCosxcglQRNAq/DZjVsC0lE40xsADsfeQoEypE+enwcOiGjk/bSuGGKHEyjSoQ1zVisanQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link href="https://fonts.googleapis.com/css2?family=Varela+Round&display=swap" rel="stylesheet">
    
    <style>
        p, .name, a{
            font-family: 'Varela Round', sans-serif;
        }
    </style>
</head>
<body>
    <section id="search">
            <nav>
                <div class="content">
                    <div class="logo">
                        <img src="Food Aid.png" alt="Food Aid Logo">
                    </div>
                    <p>FOOD AID FOUNDATION</p>
                </div>

                <ul>
                    <li><a href="home.php">Home</a></li>
                    <li><a href="donation.php">Donation</a></li>
                    <li><a href="volunteer.php">Volunteer</a></li>
                    <li><a href="aboutus.php">About Us</a></li>
                </ul>

                <div class="sicon">
                    <i class="fa-solid fa-magnifying-glass"></i>
                    <div class="search-container">
                        <form action="search.php" method="POST">
                            <input type="search" name="search" placeholder="Search">
                        </form>
                    </div>
                </div>

                <div class="uicon">
                <?php if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true) { ?>
                    <a href="logout.php">
                        <img src="logout.png" style="background-color: white; border-radius: 5px;">
                    </a>
                <?php } else { ?>
                    <a href="user.php">
                        <img src="user.png">
                    </a>
                <?php } ?>
            </div>
            </nav>

            <?php
            echo '<div class="body">';
                echo '<div class="bodys">';
                while ($row = $result->fetch_assoc()) {
                    echo '<div class="item">';
                    echo '<div class="name" style="color: #21544f; font-size: 60px; margin-bottom: 20px; margin-top: -30px; text-align: center;">' . $row['name'] . '</div>';
                    echo '<div class="image-container" style="display: flex; flex-direction: column; align-items: center;">'; 
                    echo '<img src="' . $row['image'] . '" alt="Bank Image" style="max-width: 500px; width: 100%; height: auto; margin-bottom: 20px;">';
                    echo '</div>'; 
                    echo '<div class="details" style="text-align:center; font-size: 20px;">';
                    echo '<p style="margin-bottom: 10px;">Food Bank ID: ' . $row['fbID'] . '</p>';
                    echo '<p style="margin-bottom: 10px;">Address: ' . $row['address'] . '</p>';
                    echo '<p style="margin-bottom: 10px;">Email: ' . $row['email'] . '</p>';
                    echo '<p style="margin-bottom: 10px;">Telephone Number: ' . $row['telNo'] . '</p>';
                    echo '<p style="margin-bottom: 10px;">Quantity On Hand: ' . $row['QOH'] . '</p>';
                    echo '<p>Open Hour: ' . $row['openHour'] . '</p>';
                    echo '<br><br><button style="padding:10px; border-radius:3px; border:none; width:30%; background-color:green;"><a href="donation.php" style="text-decoration:none; font-size:18px; color: white; ">Donate Now !</a></button>';
                    echo '</div>'; 
                    echo '</div>'; 
                 }

                echo '</div>'; 
            echo '</div>'; 

            $conn->close();
            ?>

        <div class="footer">
            <div class="col-1">
                <h3>FOOD AID FOUNDATION</h3>
                    <a href="home.php">Home</a>
                    <a href="donation.php">Donation</a>
                    <a href="volunteer.php">Volunteer</a>
                    <a href="aboutus.php">About Us</a>
            </div>
            <div class="col-2">
                <h3>MORE NEWS</h3> 
                <form>
                    <input type="email" placeholder="Enter Your Email">
                    <br>
                    <button type="submit">SUBSCRIBE NOW</button>
                </form>
            </div>
            <div class="col-3">
                <h3>CONTACT</h3>
                <p>012-1234567</p>
                <div class="icons">
                    <a href="https://www.instagram.com/" target="blank"><i class="fa-brands fa-instagram"></i></a>
                    <a href="https://twitter.com/" target="blank"><i class="fa-brands fa-twitter"></i></a>
                    <a href="https://www.facebook.com/" target="blank"><i class="fa-brands fa-facebook"></i></a>
                    <a href="https://www.youtube.com/" target="blank"><i class="fa-brands fa-youtube"></i></a>
                </div>
            </div>
        </div>

    </section>

    <script>
    document.addEventListener('DOMContentLoaded', function() {
        const sicon = document.querySelector('.sicon');
        const searchContainer = sicon.querySelector('.search-container');
        const searchInput = searchContainer.querySelector('input[type="search"]');
        const searchIcon = sicon.querySelector('i');
        
        // Set initial state of the search container
        searchContainer.style.display = 'none';
        
        sicon.addEventListener('click', function(event) {
            event.stopPropagation();
            sicon.classList.toggle('active');
            
            if (sicon.classList.contains('active')) {
                searchInput.style.display = 'block';
                searchContainer.style.display = 'block';
                searchIcon.style.display = 'none';
                searchInput.focus();
            } else {
                searchInput.style.display = 'none';
                searchContainer.style.display = 'none';
                searchIcon.style.display = 'block';
            }
        });
        
        // Click event listener for the document to detect clicks outside the .sicon
        document.addEventListener('click', function(event) {
            const targetElement = event.target;
            if (!sicon.contains(targetElement)) {
                sicon.classList.remove('active');
                searchInput.style.display = 'none';
                searchContainer.style.display = 'none';
                searchIcon.style.display = 'block';
            }
        });
        
        // Prevent click events inside the search container from propagating to the document click listener
        searchContainer.addEventListener('click', function(event) {
            event.stopPropagation();
        });
    });
    </script>

</body>
</html>