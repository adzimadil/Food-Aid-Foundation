<?php

session_start();

$_SESSION = array();

session_destroy();

echo "<script>alert('Logout Successful!'); window.location.href = 'home.php';</script>";

header("Location: home.php");

exit;
?>
