<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$db = "fadatabase";

$conn = new mysqli($servername, $username, $password, $db);

if ($conn->connect_error){
	die("Connection failed: ". $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST["register_submit"])){
        $userID = $_POST["userID"];
        $email = $_POST["email"];
        $password = $_POST["password"];
        $salt= "fadatabase";
        $password_encryption = sha1($password.$salt);

        $sql = "INSERT INTO tbluser (userID, email, pwd) VALUES ('$userID', '$email', '$password_encryption')";    

        if ($conn->query($sql) === TRUE) {
            echo "<script>";
            echo "setTimeout(function() { alert('Register Successful!'); window.location.href = 'home.php'; });";
            echo "</script>";
        } 
        else {
            echo "<script>alert('Error user ID duplicate. Please try again');</script>";
        }
    }
    
    else if (isset($_POST["login_submit"])){
        $userID = $_POST["userID"];
        $password = $_POST["password"];
        $salt= "fadatabase";
        $password_encryption = sha1($password.$salt);

        $sql = "SELECT * FROM tbluser WHERE userID = '$userID' AND pwd = '$password_encryption'";

        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            $_SESSION['logged_in'] = true;
            echo "<script>";
            echo "setTimeout(function() { alert('Login Successful!'); window.location.href = 'home.php'; });";
            echo "</script>";
        } 
        else {
            echo "<script>alert('Invalid login credentials. Please try again.');</script>";
        }
    }
}

$conn->close();

?>

<!DOCTYPE html>
<head>
	<title>Food Aid Foundation</title>
    <link rel="stylesheet" href="ustyle.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css" integrity="sha512-SzlrxWUlpfuzQ+pcUCosxcglQRNAq/DZjVsC0lE40xsADsfeQoEypE+enwcOiGjk/bSuGGKHEyjSoQ1zVisanQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body>
    <section id="home">
        <nav>
            <div class="content">
                <div class="logo">
                    <img src="Food Aid.png" alt="Food Aid Logo">
                </div>
                <p>FOOD AID FOUNDATION</p>
            </div>

            <ul>
                <li><a href="home.php">Home</a></li>
                <li><a href="donation.php">Donation</a></li>
                <li><a href="volunteer.php">Volunteer</a></li>
                <li><a href="aboutus.php">About Us</a></li>
            </ul>

            <div class="sicon">
                <i class="fa-solid fa-magnifying-glass"></i>
                <div class="search-container">
                    <form action="search.php" method="POST">
                        <input type="search" name="search" placeholder="Search">
                    </form>
                </div>
            </div>

            <div class="uicon">
                <?php if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true) { ?>
                    <a href="logout.php">
                        <img src="logout.png" style="background-color: white; border-radius: 5px;">
                    </a>
                <?php } else { ?>
                    <a href="user.php">
                        <img src="user.png">
                    </a>
                <?php } ?>
            </div>
        </nav>

            <div class="form">
                <div class="form-box">
                    <div class="button">
                        <div id="btn"></div>
                        <button type="button" class="toggle-btn" onClick="login()">Log In</button>
                        <button type="button" class="toggle-btn" onClick="register()">Register</button>
                    </div>                           
                <form id="login" class="input" method="POST">
                    <input type="text" name="userID" class="input-field" placeholder="User ID" required>
                    <input type="password" name="password" class="input-field" placeholder="Enter Password" required>
                    <input type="hidden" name="login_submit" value="1">
                    <input type="checkbox" class="checkbox"><span>Remember Password</span>
                    <button type="submit" class="submit-btn">Log In</button>
                </form>
                <form id="register" class="input" method="POST">
                    <input type="text" name ="userID" class="input-field" placeholder="User ID" required>
                    <input type="email" name="email" class="input-field" placeholder="Email Address" required>
                    <input type="password" name="password" class="input-field" placeholder="Enter Password" required>
                    <input type="checkbox" class="checkbox" required><span>Terms & Condition</span>
                    <input type="hidden" name="register_submit" value="1">
                    <button type="submit" class="submit-btn">Register</button>
                </form>
                </div>
            </div>

            <div class="footer">
                <div class="col-1">
                    <h3>FOOD AID FOUNDATION</h3>
                        <a href="home.php">Home</a>
                        <a href="donation.php">Donation</a>
                        <a href="volunteer.php">Volunteer</a>
                        <a href="aboutus.php">About Us</a>
                </div>
                <div class="col-2">
                    <h3>MORE NEWS</h3> 
                    <form>
                        <input type="email" placeholder="Enter Your Email">
                        <br>
                        <button type="submit">SUBSCRIBE NOW</button>
                    </form>
                </div>
                <div class="col-3">
                    <h3>CONTACT</h3>
                    <p>012-1234567</p>
                    <div class="icons">
                        <a href="https://www.instagram.com/" target="blank"><i class="fa-brands fa-instagram"></i></a>
                        <a href="https://twitter.com/" target="blank"><i class="fa-brands fa-twitter"></i></a>
                        <a href="https://www.facebook.com/" target="blank"><i class="fa-brands fa-facebook"></i></a>
                        <a href="https://www.youtube.com/" target="blank"><i class="fa-brands fa-youtube"></i></a>
                    </div>
                </div>
            </div>
    </section>

    <script>
        // User navigation
        var x = document.getElementById("login");
        var y = document.getElementById("register");
        var z = document.getElementById("btn");

        function register(){
            x.style.left = "-400px";
            y.style.left = "50px";
            z.style.left = "110px";
        }

        function login(){
            x.style.left = "50px";
            y.style.left = "450px";
            z.style.left = "0px";
        }
        
        // Search icon
        document.addEventListener('DOMContentLoaded', function() {
        const sicon = document.querySelector('.sicon');
        const searchContainer = sicon.querySelector('.search-container');
        const searchInput = searchContainer.querySelector('input[type="search"]');
        const searchIcon = sicon.querySelector('i');
        
        // Set initial state of the search container
        searchContainer.style.display = 'none';
        
        sicon.addEventListener('click', function(event) {
            event.stopPropagation();
            sicon.classList.toggle('active');
            
            if (sicon.classList.contains('active')) {
                searchInput.style.display = 'block';
                searchContainer.style.display = 'block';
                searchIcon.style.display = 'none';
                searchInput.focus();
            } else {
                searchInput.style.display = 'none';
                searchContainer.style.display = 'none';
                searchIcon.style.display = 'block';
            }
        });
        
        // Click event listener for the document to detect clicks outside the .sicon
        document.addEventListener('click', function(event) {
            const targetElement = event.target;
            if (!sicon.contains(targetElement)) {
                sicon.classList.remove('active');
                searchInput.style.display = 'none';
                searchContainer.style.display = 'none';
                searchIcon.style.display = 'block';
            }
        });
        
        // Prevent click events inside the search container from propagating to the document click listener
        searchContainer.addEventListener('click', function(event) {
            event.stopPropagation();
        });
        });
    </script>

</body>
</html>