<?php   session_start(); ?>
<html>
<head>
    <title>Food Aid Foundation</title>
    <link rel="stylesheet" href="../../../Users/user/OneDrive/Documents/Web%20development/hstyle.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css" integrity="sha512-SzlrxWUlpfuzQ+pcUCosxcglQRNAq/DZjVsC0lE40xsADsfeQoEypE+enwcOiGjk/bSuGGKHEyjSoQ1zVisanQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
	<head>
	<title>Volunteering Form</title>
	<style>
		*{
			margin: 0;
			padding: 0;
			box-sizing: border-box;
			font-family: sans-serif;
		}

		html{
			scroll-behavior: smooth;
		}

		#home{
			width: 100%;
			height: auto;
			background-color: white;
		}

		/*Navigation bar*/

		section nav{
			display: flex;
			justify-content: space-around;
			align-items: center;
			position: fixed;
			right: 0;
			left: 0;
			background: #21544f;
			box-shadow: 0 0 10px rgba(0,0,0,0.5);
			z-index: 1000;
		}

		section nav .content{
			display: flex;
			align-items: center;
		}

		section nav .content p{
			display: inline-block;
			margin: 0 15px;
			color: white;
			font-weight: bold;
			cursor: pointer;
		}

		section nav .logo img{
			width: 60px;
			cursor: pointer;
			margin: 7px 0;
			border-radius: 10px;
		}

		section nav ul{
			list-style: none;
		}

		section nav ul li{
			display: inline-block;
			margin: 0 15px;
		}

		section nav ul li a{
			text-decoration: none;
			color: white;
			font-weight: 500;
			font-size: 17px;
			transition: 0.1s;
		}

		section nav ul li a::after{
			content: '';
			width: 0%;
			height: 2px;
			background: #fac031;
			display: block;
			transition: 0.2s linear;
		}

		section nav ul li a:hover::after{
			width: 100%;
		}

		section nav ul li a:hover{
			color: #fac031;
		}

		section nav .sicon i{
			font-size: 18px;
			color: white;
			margin: 0 5px;
			cursor: pointer;
			transition: 0.2s;
		}

		section nav .sicon i:hover{
			color: #fac031;
		}

		section nav .uicon img{
			height: 30px;
			width: auto;
			margin: 0 5px;
			cursor: pointer;
			transition: 0.2s;
		}

		section nav .uicon img:hover {
			filter: brightness(50%);
		}

		/*End Navigation*/

        section .form{
            display: flex;
            align-items: center;
        }

		section .form form{
            margin: 50px auto;
            margin-top: 100px;
			width: 400px;
			font-family: Arial, sans-serif;
			border: 2px solid #ccc;
			padding: 20px;
			border-radius: 10px;
		}

		section .form label{
			display: block;
			margin-bottom: 10px;
		}

		section .form input[type=text], select, textarea {
			width: 100%;
			padding: 10px;
			margin-bottom: 20px;
			border-radius: 5px;
			border: 1px solid #ccc;
			box-sizing: border-box;
			font-size: 16px;
			font-family: Arial, sans-serif;
		}

		section .form input[type=radio], input[type=checkbox] {
			margin-right: 10px;
		}

		section .form textarea {
			height: 120px;
		}

		section .form input[type=submit], input[type=reset] {
			background-color: #4CAF50;
			color: white;
			padding: 10px 20px;
			border: none;
			border-radius: 5px;
			cursor: pointer;
			font-size: 16px;
			font-family: Arial, sans-serif;
			margin-top: 20px;
		}

		section .form input[type=reset] {
			background-color: #f44336;
		}

		/*Footer*/

		section .footer{
			margin-top: 100px;
			width: 100%;
			padding: 20px 15%;
			background: #21544f;
			color: white;
			display: flex;
		}

		section .footer div{
			text-align: center;
		}

		section .footer .col-1{
			position: relative;
			left: -20px;
			display: flex;
			flex-direction: column;
		}

		section .footer .col-1 h3{
			font-weight: auto;
			margin-bottom: 30px;
			letter-spacing: 1px;
		}

		section .footer .col-1 a{
			display: inline-block;
			text-decoration: none;
			color:  rgb(255, 255, 242);
			margin-bottom: 20px;
			position: relative;
		}

		section .footer .col-1 a:hover{
			color: #fac031;
		}

		section .footer .col-1 a::after{
			content: "";
			width: 0;
			height: 2px;
			background: #fac031;
			display: block;
			transition: 0.2s linear;
			position: absolute;
			bottom: 0;
			left: 50%;
			transform: translateX(-50%);
		}

		section .footer .col-1 a:hover::after{
			width: 30%;
		}

		section .footer .col-2{
			flex-grow: 2;
			position: relative;
			left: -30px;
		}

		section .footer .col-2 form input{
			width: 400px;
			height: 45px;
			border-radius: 4px;
			text-align: center;
			margin-top: 20px;
			margin-bottom: 40px;
			outline: none;
			border: none;
			background-color:  rgb(255, 255, 242);
		}

		section .footer .col-2 form input:hover{
			background-color: lightgrey;
		}

		section .footer .col-2 form button{
			background: transparent;
			border: 2px solid  rgb(255, 255, 242);
			color:  rgb(255, 255, 242);
			border-radius: 30px;
			padding: 10px 30px;
			font-size: 15px;
			cursor: pointer;
		}

		section .footer .col-2 form button:hover{
			background-color: #fac031;
		}

		section .footer .col-3{
			position: relative;
			left: -30px;
		}

		section .footer .col-3 h3{
			font-weight: auto;
			margin-bottom: 30px;
			letter-spacing: 1px;
		}

		section .footer .col-3 p{
			color:  rgb(255, 255, 242);
			cursor: pointer;
		}

		section .footer .col-3 .icons{
			margin-top: 20px;
		}

		section .footer .col-3 .icons i{
			font-size: 20px;
			margin: 10px;
			color: rgb(255, 255, 242);
			cursor: pointer;
		}

		section .footer .col-3 .icons i:hover{
			color: #fac031;
		}
        
section nav .sicon{
    position: relative;
    display: inline-block;
}

section nav .sicon i{
    font-size: 18px;
    color: white;
    margin: 0 5px;
    cursor: pointer;
    transition: 0.2s;
}

section nav .sicon i:hover{
    color: #fac031;
}

section nav .sicon .active i{
    display: none;
}

section nav .sicon .search-container{
    display: none;
}

section nav .sicon .active .search-container{
    display: block;
}

section nav .sicon .search-container input{
    width: 160px;
    height: 25px;
    outline: none;
    border: none;
    border-radius: 5px;
    text-align: center;
    background-color: rgb(255, 255, 242);
}

		/*End Footer*/

	</style>
</head>
<body>
	<section id="home">
        <nav>
            <div class="content">
                <div class="logo">
                    <img src="Food%20Aid.png" alt="Food Aid Logo">
                </div>
                <p>FOOD AID FOUNDATION</p>
            </div>

            <ul>
                <li><a href="home.php">Home</a></li>
                <li><a href="donation.php">Donation</a></li>
                <li><a href="volunteer.php">Volunteer</a></li>
                <li><a href="aboutus.php">About Us</a></li>
            </ul>

            <div class="sicon">
                    <i class="fa-solid fa-magnifying-glass"></i>
                    <div class="search-container">
                        <form action="search.php" method="POST">
                            <input type="search" name="search" placeholder="Search">
                        </form>
                    </div>
                </div>

            <div class="uicon">
                <?php if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true) { ?>
                    <a href="logout.php">
                        <img src="logout.png" style="background-color: white; border-radius: 5px;">
                    </a>
                <?php } else { ?>
                    <a href="user.php">
                        <img src="user.png">
                    </a>
                <?php } ?>
            </div>
        </nav>

        <div class="form">
		    <form method="post" action="cash.php">
                <h2>Cash Donation Form</h2><br>
                <label>Full Name:</label>
                <input type="text" id="fullName" name="fullName" required>
               
                <label>Phone Number:</label>
                <input type="text" id="phoneNo" name="phoneNo" required>
                
                <label>Payment Method:</label>
    			<select id="method" name="method" >
      			<option value="">Select a payment method</option>
      			<option value="Credit/Debit Card">Credit Card/Debit Card</option>
     			<option value="TnG eWallet">TnG eWallet</option>
      			<option value="Online Banking">Online Banking</option>
    			</select><br><br>

    			<label>Amount:</label>
    			<input type="text" id="amount" name="amount" required>
                
                <br>
                <input type="submit" value="Submit">
                <input type="reset" value="Cancel">
		    </form>
        </div>

		<div class="footer">
            <div class="col-1">
                <h3>FOOD AID FOUNDATION</h3>
                    <a href="home.php">Home</a>
                    <a href="donation.php">Donation</a>
                    <a href="volunteer.php">Volunteer</a>
                    <a href="aboutus.php">About Us</a>
            </div>
            <div class="col-2">
                <h3>MORE NEWS</h3> 
                <form>
                    <input type="email" placeholder="Enter Your Email">
                    <br>
                    <button type="submit">SUBSCRIBE NOW</button>
                </form>
            </div>
            <div class="col-3">
                <h3>CONTACT</h3>
                <p>012-1234567</p>
                <div class="icons">
                    <a href="https://www.instagram.com/" target="blank"><i class="fa-brands fa-instagram"></i></a>
                    <a href="https://twitter.com/" target="blank"><i class="fa-brands fa-twitter"></i></a>
                    <a href="https://www.facebook.com/" target="blank"><i class="fa-brands fa-facebook"></i></a>
                    <a href="https://www.youtube.com/" target="blank"><i class="fa-brands fa-youtube"></i></a>
                </div>
            </div>
        </div>
    </section>
</body>
        <script>
    document.addEventListener('DOMContentLoaded', function() {
        const sicon = document.querySelector('.sicon');
        const searchContainer = sicon.querySelector('.search-container');
        const searchInput = searchContainer.querySelector('input[type="search"]');
        const searchIcon = sicon.querySelector('i');
        
        // Set initial state of the search container
        searchContainer.style.display = 'none';
        
        sicon.addEventListener('click', function(event) {
            event.stopPropagation();
            sicon.classList.toggle('active');
            
            if (sicon.classList.contains('active')) {
                searchInput.style.display = 'block';
                searchContainer.style.display = 'block';
                searchIcon.style.display = 'none';
                searchInput.focus();
            } else {
                searchInput.style.display = 'none';
                searchContainer.style.display = 'none';
                searchIcon.style.display = 'block';
            }
        });
        
        // Click event listener for the document to detect clicks outside the .sicon
        document.addEventListener('click', function(event) {
            const targetElement = event.target;
            if (!sicon.contains(targetElement)) {
                sicon.classList.remove('active');
                searchInput.style.display = 'none';
                searchContainer.style.display = 'none';
                searchIcon.style.display = 'block';
            }
        });
        
        // Prevent click events inside the search container from propagating to the document click listener
        searchContainer.addEventListener('click', function(event) {
            event.stopPropagation();
        });
    });
    </script>
</html>
