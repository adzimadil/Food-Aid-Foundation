
<?php
 session_start();

$fullName= $_POST['fullName'];
$age= $_POST['age'];
$gender= $_POST['gender'];
$email= $_POST['email'];
$phoneNo= $_POST['phoneNo'];
$location= $_POST['location'];
$time= $_POST['time'];
$date= $_POST['date'];


// Create connection
$conn = mysqli_connect('localhost','root','','fadatabase');

$sql = "INSERT INTO `tblvolunteer` (`name`,`email`, `telNo`, `location`, `time`, `date`,`age`,`gender`) VALUES ('$fullName','$email','$phoneNo','$location','$time','$date','$age','$gender')"; 
//echo $sql;
// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}

if(mysqli_query($conn,$sql)){
echo"<script> function myFunc() {document.getElementById('box').style.display:'block';} </script>";  
}


?>

<html>
<head> 
 <style>
 *{
			margin: 0;
			padding: 0;
			box-sizing: border-box;
			font-family: sans-serif;
		}

		html{
			scroll-behavior: smooth;
		}

		#home{
			width: 100%;
			height: auto;
			background-color: white;
		}

		/*Navigation bar*/

		section nav{
			display: flex;
			justify-content: space-around;
			align-items: center;
			position: fixed;
			right: 0;
			left: 0;
			background: #21544f;
			box-shadow: 0 0 10px rgba(0,0,0,0.5);
			z-index: 1000;
		}

		section nav .content{
			display: flex;
			align-items: center;
		}

		section nav .content p{
			display: inline-block;
			margin: 0 15px;
			color: white;
			font-weight: bold;
			cursor: pointer;
		}

		section nav .logo img{
			width: 60px;
			cursor: pointer;
			margin: 7px 0;
			border-radius: 10px;
		}

		section nav ul{
			list-style: none;
		}

		section nav ul li{
			display: inline-block;
			margin: 0 15px;
		}

		section nav ul li a{
			text-decoration: none;
			color: white;
			font-weight: 500;
			font-size: 17px;
			transition: 0.1s;
		}

		section nav ul li a::after{
			content: '';
			width: 0%;
			height: 2px;
			background: #fac031;
			display: block;
			transition: 0.2s linear;
		}

		section nav ul li a:hover::after{
			width: 100%;
		}

		section nav ul li a:hover{
			color: #fac031;
		}

		section nav .sicon i{
			font-size: 18px;
			color: white;
			margin: 0 5px;
			cursor: pointer;
			transition: 0.2s;
		}

		section nav .sicon i:hover{
			color: #fac031;
		}

		section nav .uicon img{
			height: 30px;
			width: auto;
			margin: 0 5px;
			cursor: pointer;
			transition: 0.2s;
		}

		section nav .uicon img:hover {
			filter: brightness(50%);
		}

        /*End Navigation*/

        section .container{
            display: flex;
            justify-content: center;
            align-items: center;
            height: 700px;
        }

        section .container .texts{
            border: 1px solid black;
            padding: 20px;
            margin-bottom: 50px;
        }

        section .container .texts h1{
            margin-bottom: 30px;
        }

        section .container .texts p{
            margin-bottom: 30px;
        }

        section .container .texts ul{
            margin-bottom: 30px;
            margin-left: 30px;
        }
        

		/*Footer*/

		section .footer{
			margin-top: -100px;
			width: 100%;
			padding: 20px 15%;
			background: #21544f;
			color: white;
			display: flex;
		}

		section .footer div{
			text-align: center;
		}

		section .footer .col-1{
			position: relative;
			left: -20px;
			display: flex;
			flex-direction: column;
		}

		section .footer .col-1 h3{
			font-weight: auto;
			margin-bottom: 30px;
			letter-spacing: 1px;
		}

		section .footer .col-1 a{
			display: inline-block;
			text-decoration: none;
			color:  rgb(255, 255, 242);
			margin-bottom: 20px;
			position: relative;
		}

		section .footer .col-1 a:hover{
			color: #fac031;
		}

		section .footer .col-1 a::after{
			content: "";
			width: 0;
			height: 2px;
			background: #fac031;
			display: block;
			transition: 0.2s linear;
			position: absolute;
			bottom: 0;
			left: 50%;
			transform: translateX(-50%);
		}

		section .footer .col-1 a:hover::after{
			width: 30%;
		}

		section .footer .col-2{
			flex-grow: 2;
			position: relative;
			left: -30px;
		}

		section .footer .col-2 form input{
			width: 400px;
			height: 45px;
			border-radius: 4px;
			text-align: center;
			margin-top: 20px;
			margin-bottom: 40px;
			outline: none;
			border: none;
			background-color:  rgb(255, 255, 242);
		}

		section .footer .col-2 form input:hover{
			background-color: lightgrey;
		}

		section .footer .col-2 form button{
			background: transparent;
			border: 2px solid  rgb(255, 255, 242);
			color:  rgb(255, 255, 242);
			border-radius: 30px;
			padding: 10px 30px;
			font-size: 15px;
			cursor: pointer;
		}

		section .footer .col-2 form button:hover{
			background-color: #fac031;
		}

		section .footer .col-3{
			position: relative;
			left: -30px;
		}

		section .footer .col-3 h3{
			font-weight: auto;
			margin-bottom: 30px;
			letter-spacing: 1px;
		}

		section .footer .col-3 p{
			color:  rgb(255, 255, 242);
			cursor: pointer;
		}

		section .footer .col-3 .icons{
			margin-top: 20px;
		}

		section .footer .col-3 .icons i{
			font-size: 20px;
			margin: 10px;
			color: rgb(255, 255, 242);
			cursor: pointer;
		}

		section .footer .col-3 .icons i:hover{
			color: #fac031;
		}

 .container{
            display: flex;
            justify-content: center;
            align-items: center;
            height: 700px;
        }

         .container .texts{
            border: 1px solid black;
            padding: 20px;
            margin-bottom: 50px;
        }

        .container .texts h1{
            margin-bottom: 30px;
        }

        .container .texts p{
            margin-bottom: 30px;
        }

        .container .texts ul{
            margin-bottom: 30px;
            margin-left: 30px;
        }
     
     section nav .sicon{
    position: relative;
    display: inline-block;
}

section nav .sicon i{
    font-size: 18px;
    color: white;
    margin: 0 5px;
    cursor: pointer;
    transition: 0.2s;
}

section nav .sicon i:hover{
    color: #fac031;
}

section nav .sicon .active i{
    display: none;
}

section nav .sicon .search-container{
    display: none;
}

section nav .sicon .active .search-container{
    display: block;
}

section nav .sicon .search-container input{
    width: 160px;
    height: 25px;
    outline: none;
    border: none;
    border-radius: 5px;
    text-align: center;
    background-color: rgb(255, 255, 242);
}
 </style>
</head>
<body>
	<section id="home">
        <nav>
            <div class="content">
                <div class="logo">
                    <img src="Food Aid.png" alt="Food Aid Logo">
                </div>
                <p>FOOD AID FOUNDATION</p>
            </div>

            <ul>
                <li><a href="home.php">Home</a></li>
                <li><a href="donation.php">Donation</a></li>
                <li><a href="volunteer.php">Volunteer</a></li>
                <li><a href="aboutus.php">About Us</a></li>
            </ul>

            <div class="sicon">
                    <i class="fa-solid fa-magnifying-glass"></i>
                    <div class="search-container">
                        <form action="search.php" method="POST">
                            <input type="search" name="search" placeholder="Search">
                        </form>
                    </div>
                </div>

            <div class="uicon">
                <?php if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true) { ?>
                    <a href="logout.php">
                        <img src="logout.png" style="background-color: white; border-radius: 5px;">
                    </a>
                <?php } else { ?>
                    <a href="user.php">
                        <img src="user.png">
                    </a>
                <?php } ?>
            </div>
        </nav>

        <div class="container" id="myFunc()">
            <div class="texts" id="box">
                <h1>Thank You For Volunteering</h1>
                <p>We have received your submission and will process it shortly.</p>
                <p>Here are the details of your submission:</p>
                
                <ul>
                    <li><b>Name:</b> <?php echo $fullName?> </li>
                    <li><b>Email:</b> <?php echo $email?></li>
                    <li><b>Phone:</b> <?php echo $phoneNo?></li>
                </ul>
                
                <p>If there are any further updates required, we will get in touch with you.</p>
            </div>
            </div>
            <div class="footer">
            <div class="col-1">
                <h3>FOOD AID FOUNDATION</h3>
                    <a href="home.php">Home</a>
                    <a href="donation.php">Donation</a>
                    <a href="volunteer.php">Volunteer</a>
                    <a href="aboutus.php">About Us</a>
            </div>
            <div class="col-2">
                <h3>MORE NEWS</h3> 
                <form>
                    <input type="email" placeholder="Enter Your Email">
                    <br>
                    <button type="submit">SUBSCRIBE NOW</button>
                </form>
            </div>
            <div class="col-3">
                <h3>CONTACT</h3>
                <p>012-1234567</p>
                <div class="icons">
                    <a href="https://www.instagram.com/" target="blank"><i class="fa-brands fa-instagram"></i></a>
                    <a href="https://twitter.com/" target="blank"><i class="fa-brands fa-twitter"></i></a>
                    <a href="https://www.facebook.com/" target="blank"><i class="fa-brands fa-facebook"></i></a>
                    <a href="https://www.youtube.com/" target="blank"><i class="fa-brands fa-youtube"></i></a>
                </div>
            </div>
        </div>
    </section>

            
 </body> 
        <script>
    document.addEventListener('DOMContentLoaded', function() {
        const sicon = document.querySelector('.sicon');
        const searchContainer = sicon.querySelector('.search-container');
        const searchInput = searchContainer.querySelector('input[type="search"]');
        const searchIcon = sicon.querySelector('i');
        
        // Set initial state of the search container
        searchContainer.style.display = 'none';
        
        sicon.addEventListener('click', function(event) {
            event.stopPropagation();
            sicon.classList.toggle('active');
            
            if (sicon.classList.contains('active')) {
                searchInput.style.display = 'block';
                searchContainer.style.display = 'block';
                searchIcon.style.display = 'none';
                searchInput.focus();
            } else {
                searchInput.style.display = 'none';
                searchContainer.style.display = 'none';
                searchIcon.style.display = 'block';
            }
        });
        
        // Click event listener for the document to detect clicks outside the .sicon
        document.addEventListener('click', function(event) {
            const targetElement = event.target;
            if (!sicon.contains(targetElement)) {
                sicon.classList.remove('active');
                searchInput.style.display = 'none';
                searchContainer.style.display = 'none';
                searchIcon.style.display = 'block';
            }
        });
        
        // Prevent click events inside the search container from propagating to the document click listener
        searchContainer.addEventListener('click', function(event) {
            event.stopPropagation();
        });
    });
    </script>
    
 <?php mysqli_close($conn); ?>       
</html>
