<?php

session_start();

?>

<!DOCTYPE html>
<html>
<head>
	<title>Food Aid Foundation</title>
    <link rel="stylesheet" href="hstyle.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css" integrity="sha512-SzlrxWUlpfuzQ+pcUCosxcglQRNAq/DZjVsC0lE40xsADsfeQoEypE+enwcOiGjk/bSuGGKHEyjSoQ1zVisanQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body>
    <section id="home">
        <nav>
            <div class="content">
                <div class="logo">
                    <img src="Food Aid.png" alt="Food Aid Logo">
                </div>
                <p>FOOD AID FOUNDATION</p>
            </div>

            <ul>
                <li><a href="home.php">Home</a></li>
                <li><a href="donation.php">Donation</a></li>
                <li><a href="volunteer.php">Volunteer</a></li>
                <li><a href="aboutus.php">About Us</a></li>
            </ul>

            <div class="sicon">
                <i class="fa-solid fa-magnifying-glass"></i>
                <div class="search-container">
                    <form action="search.php" method="POST">
                        <input type="search" name="search" placeholder="Search">
                    </form>
                </div>
            </div>

            <div class="uicon">
                <?php if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true) { ?>
                    <a href="logout.php">
                        <img src="logout.png" style="background-color: white; border-radius: 5px;">
                    </a>
                <?php } else { ?>
                    <a href="user.php">
                        <img src="user.png">
                    </a>
                <?php } ?>
            </div>
        </nav>

        <div class="body">
            <div class="png1">
                <img src="Home.png">
            </div>
            <div class="logo2">
                <img src="Food Aid.png">
            </div>
            <div class="title">
                <h2>What is Food Aid Foundation?</h2>
            </div>
            <p><span>Food Aid Foundation as a food bank in Malaysia</span> is a non-profit governmental organization (NGO)
                incorporated on 2013 that is where manufacturers, distributors, wholesaler,<br> retailers, 
                companies or people can donate their unused or unwanted foods which will then be collected and distributed to charitable/welfare<br> 
                homes, volunteer welfare organisation, refugees community, poor families, destitute and soup kitchen.<br><br><br>
                In short we rescue surplus food from the supply chain and distributing food to people in need.<br><br><br><br>
            </p>
        </div>

        <div class="body2">
            <div class="theme">
                <h3>How does Food Aid Foundation operates?</h3>
            </div>
            <div class="png2">
                <img src="About us .png">
            </div>
            <div class="button">
                <a href="aboutus.php">Learn More About Us</a>
                <i class="fa-solid fa-angle-right"></i>
            </div>
        </div>

        <div class="footer">
            <div class="col-1">
                <h3>FOOD AID FOUNDATION</h3>
                    <a href="home.php">Home</a>
                    <a href="donation.html">Donation</a>
                    <a href="volunteer.html">Volunteer</a>
                    <a href="aboutus.html">About Us</a>
            </div>
            <div class="col-2">
                <h3>MORE NEWS</h3> 
                <form>
                    <input type="email" placeholder="Enter Your Email">
                    <br>
                    <button type="submit">SUBSCRIBE NOW</button>
                </form>
            </div>
            <div class="col-3">
                <h3>CONTACT</h3>
                <p>012-1234567</p>
                <div class="icons">
                    <a href="https://www.instagram.com/" target="blank"><i class="fa-brands fa-instagram"></i></a>
                    <a href="https://twitter.com/" target="blank"><i class="fa-brands fa-twitter"></i></a>
                    <a href="https://www.facebook.com/" target="blank"><i class="fa-brands fa-facebook"></i></a>
                    <a href="https://www.youtube.com/" target="blank"><i class="fa-brands fa-youtube"></i></a>
                </div>
            </div>
        </div>
    </section>

    <script>
    document.addEventListener('DOMContentLoaded', function() {
        const sicon = document.querySelector('.sicon');
        const searchContainer = sicon.querySelector('.search-container');
        const searchInput = searchContainer.querySelector('input[type="search"]');
        const searchIcon = sicon.querySelector('i');
        
        // Set initial state of the search container
        searchContainer.style.display = 'none';
        
        sicon.addEventListener('click', function(event) {
            event.stopPropagation();
            sicon.classList.toggle('active');
            
            if (sicon.classList.contains('active')) {
                searchInput.style.display = 'block';
                searchContainer.style.display = 'block';
                searchIcon.style.display = 'none';
                searchInput.focus();
            } else {
                searchInput.style.display = 'none';
                searchContainer.style.display = 'none';
                searchIcon.style.display = 'block';
            }
        });
        
        // Click event listener for the document to detect clicks outside the .sicon
        document.addEventListener('click', function(event) {
            const targetElement = event.target;
            if (!sicon.contains(targetElement)) {
                sicon.classList.remove('active');
                searchInput.style.display = 'none';
                searchContainer.style.display = 'none';
                searchIcon.style.display = 'block';
            }
        });
        
        // Prevent click events inside the search container from propagating to the document click listener
        searchContainer.addEventListener('click', function(event) {
            event.stopPropagation();
        });
    });
    </script>

</body>
</html>