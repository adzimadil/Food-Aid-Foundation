<?php   session_start(); ?>
<!DOCTYPE html>

<html>
<head>
	<title>Food Aid Foundation</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css" integrity="sha512-SzlrxWUlpfuzQ+pcUCosxcglQRNAq/DZjVsC0lE40xsADsfeQoEypE+enwcOiGjk/bSuGGKHEyjSoQ1zVisanQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />

<style>
   section nav .sicon{
    position: relative;
    display: inline-block;
}

section nav .sicon i{
    font-size: 18px;
    color: white;
    margin: 0 5px;
    cursor: pointer;
    transition: 0.2s;
}

section nav .sicon i:hover{
    color: #fac031;
}

section nav .sicon .active i{
    display: none;
}

section nav .sicon .search-container{
    display: none;
}

section nav .sicon .active .search-container{
    display: block;
}

section nav .sicon .search-container input{
    width: 160px;
    height: 25px;
    outline: none;
    border: none;
    border-radius: 5px;
    text-align: center;
    background-color: rgb(255, 255, 242);
} 

</style> 
    

</head>
<body>
    <section id="Home">
        <nav>
            <div class="content">
                <div class="logo">
                    <img src="Food%20Aid.png" alt="Food Aid Logo">
                </div>
                <p>FOOD AID FOUNDATION</p>
            </div>

            <ul>
                <li><a href="home.php">Home</a></li>
                <li><a href="donation.php">Donation</a></li>
                <li><a href="volunteer.php">Volunteer</a></li>
                <li><a href="aboutus.php">About Us</a></li>
            </ul>
            
            <div class="sicon">
                    <i class="fa-solid fa-magnifying-glass"></i>
                    <div class="search-container">
                        <form action="search.php" method="POST">
                            <input type="search" name="search" placeholder="Search">
                        </form>
                    </div>
                </div>
<div class="uicon">
                <?php if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true) { ?>
                    <a href="logout.php">
                        <img src="logout.png" style="background-color: white; border-radius: 5px;">
                    </a>
                <?php } else { ?>
                    <a href="user.php">
                        <img src="user.png">
                    </a>
                <?php } ?>
            </div>

        </nav>

        
        
        
        
        <section class="header">
        <div class="text-box">
            <h1>Donate</h1>
        </div>
        </section>
      
        
        <!-----Donation----->
    
        <section class="donation">
        <h1>Method of Donation</h1>
    
    
        <div class="row">
        <div class="donation-col" style="background-image: url(https://theprepared.com/wp-content/uploads/2021/05/cash-hero-TP.jpg); background: cover; background-position: center; background-repeat: no-repeat; background-size: cover;">
            <h3 style="margin-top: 45px; background: cornsilk; border: 1px solid burlywood;"><a href="cashpage.php" style="color: black;">Cash Donation</a></h3>
        </div>
    
        <div class="donation-col" style="background-image: url(https://www.tasteofhome.com/wp-content/uploads/2017/10/shutterstock_67513879.jpg); background-position: center; background-repeat: no-repeat; background-size: cover;">
            <h3 style="margin-top: 45px; background: cornsilk; border: 1px solid burlywood;"><a href="food-donation.php" style="color: black;">Food Donation</a></h3>
        </div>
    </div>
    
    

    </section>
        

        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        <div class="footer" style="margin-top:10px;">
            <div class="col-1">
                <h3>FOOD AID FOUNDATION</h3>
                    <a href="home.php">Home</a>
                    <a href="donation.php">Donation</a>
                    <a href="volunteer.php">Volunteer</a>
                    <a href="aboutus.php">About Us</a>
            </div>
            <div class="col-2">
                <h3>MORE NEWS</h3> 
                <form>
                    <input type="email" placeholder="Enter Your Email">
                    <br>
                    <button type="submit">SUBSCRIBE NOW</button>
                </form>
            </div>
            <div class="col-3">
                <h3>CONTACT</h3>
                <p>012-1234567</p>
                <div class="icons">
                    <a href="https://www.instagram.com/" target="blank"><i class="fa-brands fa-instagram"></i></a>
                    <a href="https://twitter.com/" target="blank"><i class="fa-brands fa-twitter"></i></a>
                    <a href="https://www.facebook.com/" target="blank"><i class="fa-brands fa-facebook"></i></a>
                    <a href="https://www.youtube.com/" target="blank"><i class="fa-brands fa-youtube"></i></a>
                </div>
            </div>
        </div>
    </section>
</body>
        <script>
    document.addEventListener('DOMContentLoaded', function() {
        const sicon = document.querySelector('.sicon');
        const searchContainer = sicon.querySelector('.search-container');
        const searchInput = searchContainer.querySelector('input[type="search"]');
        const searchIcon = sicon.querySelector('i');
        
        // Set initial state of the search container
        searchContainer.style.display = 'none';
        
        sicon.addEventListener('click', function(event) {
            event.stopPropagation();
            sicon.classList.toggle('active');
            
            if (sicon.classList.contains('active')) {
                searchInput.style.display = 'block';
                searchContainer.style.display = 'block';
                searchIcon.style.display = 'none';
                searchInput.focus();
            } else {
                searchInput.style.display = 'none';
                searchContainer.style.display = 'none';
                searchIcon.style.display = 'block';
            }
        });
        
        // Click event listener for the document to detect clicks outside the .sicon
        document.addEventListener('click', function(event) {
            const targetElement = event.target;
            if (!sicon.contains(targetElement)) {
                sicon.classList.remove('active');
                searchInput.style.display = 'none';
                searchContainer.style.display = 'none';
                searchIcon.style.display = 'block';
            }
        });
        
        // Prevent click events inside the search container from propagating to the document click listener
        searchContainer.addEventListener('click', function(event) {
            event.stopPropagation();
        });
    });
    </script>
</html>