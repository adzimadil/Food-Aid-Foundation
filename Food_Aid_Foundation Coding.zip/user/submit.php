<?php

// Retrieve the form data
$name = $_POST['name'];
$phoneNum = $_POST['phoneNum'];
$pickDate = $_POST['pickDate'];
$pickTime = $_POST['pickTime'];
$address = $_POST['address'];
$totalItems = $_POST['totalItems'];

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "fadatabase";
$conn = new mysqli($servername, $username, $password, $dbname);

$sql = "INSERT INTO tbldonation (name, phoneNum, pickDate, pickTime, address, totalItems) VALUES ('$name', '$phoneNum', '$pickDate', '$pickTime', '$address', '$totalItems')";


if (!preg_match("/[0-9]{2,3}-[0-9]{7,8}/",$phoneNum)){
    echo "<script>alert('Please enter right phone number format'); window.location.href='food-donation.php#top';</script>;";  
}
else{
    if(mysqli_query($conn, $sql)){
        echo "Data stored successfully!";
        echo "<script>alert('Thank You for donation!');window.location.href='food-donation.php';</script>";
    }else{
    echo "Error storing data: " . mysqli_error($conn);
    }
}
// Connect to the database


// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

else{
    echo "Sucessfully connected to database $dbname.";

}




// Data validation

if(empty($_POST["phoneNum"]))	
    die('Fill in HP Num');

else
    $phoneNum=$_POST["phoneNum"];


mysqli_close($conn);



?>

