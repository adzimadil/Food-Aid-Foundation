<?php
session_start();

$adminID=$_SESSION['adminID'];

$id= isset($_GET["requestID"])?$_GET["requestID"]:"";

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "fadatabase";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}

$sql = "SELECT * FROM tbldonation WHERE requestID=$id;";

$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
  // output data of each row
 
  while($row = mysqli_fetch_assoc($result)) {
$id=$row["requestID"];
$name= $row["name"];
$tel = $row["phoneNum"];
$date = $row["pickDate"];
$address = $row["address"];
$time = $row["pickTime"];
$stat = $row["status"];
$qoh = $row["totalItems"];
    
  }
} 


mysqli_close($conn);


?>

<!DOCTYPE HTML>
<html>
    <head>   <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <title>Food Aid Foundation</title>
    
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
    <link rel ="stylesheet" href="fdAddStyle.css">
    
    
    </head>
        <section class="container">
    <header>Donation Request edit information form</header>
        <form action="fdEdit2.php" method="POST" class="form">
            
            <div class="input-box" >
                <label>ID</label>
                <input type="text" placeholder="Enter full name" name="requestID" id="requestID" value="<?=$id?>" >
            </div>
            
            <div class="input-box" >
                <label>Full Name</label>
                <input type="text" placeholder="Enter full name" name="name" id="name" value="<?=$name?>" >
            </div>
            
            <div class="input-box" >
                <label>Phone Number</label>
                <input type="number" placeholder="Enter phone number" name="tel" id="tel" value="<?php echo $tel?>">
                </div>    
                
            <div class="input-box">
                <label>Pick Up Date</label>
                <input type="date" placeholder="Enter pick up date" name="date" id="date" value="<?php echo $date?>" >
            </div>
                
            <div class="input-box">
                <label>Pick Up Time</label>
                <input type="time" placeholder="Enter pick up time"  name="time" id="time" value="<?php echo $time?>">
            </div>
            
            <div class="input-box" >
                <label>Address</label>
                <input type="text" placeholder="Enter street address" name="address" id="address" value="<?=$address?>">
            </div>
            
            <div class="input-box" >
                <label>Status</label>
                <select name="stat" id="stat">
                    <option value="Verifying" <?php if ($stat=="Verifying"){?>
                       selected <?php } ?> >Verifying</option>
                    <option value="Completed"<?php if ($stat=="Completed"){?>
                       selected <?php } ?>>Completed</option>
                    <option value="Rejected" <?php if ($stat=="Rejected"){?>
                       selected <?php } ?>>Rejected</option>
                    <option value="Pending" <?php if ($stat=="Pending"){?>
                       selected <?php } ?>>Pending</option>
                </select>
            </div>
            
            <div class="input-box">
                <label>Total Items</label>
                <input type="number" name="quantity" id="quantity"value="<?=$qoh?>" >
            </div>
            <button type="submit">Submit</button>
        </form>
             <a href="fd.php?adminID=<?php echo $adminID ?>"><button style="padding:0.5rem; border-radius:5px; border:none; font-size:15px; background-color:red; color:white; margin-top:0.7rem; margin-left:18.3rem;">Take Me Back !</button></a>
    </section>
</html>