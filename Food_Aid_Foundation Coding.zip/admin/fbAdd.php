<?php 
session_start();

$adminID=$_SESSION['adminID'];

?>

<!DOCTYPE HTML>
<html>
    <head>   <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <title>Food Aid Foundation</title>
    
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
    <link rel ="stylesheet" href="fdAddStyle.css">
    
    </head>
        <section class="container">
    <header>Food Bank Form</header>
        <form action="fbAdd2.php" method="POST" class="form">
            
            <div class="input-box" >
                <label>ID</label>
                <input type="text" placeholder="Enter ID" name="fbID" id="fbID" >
            </div>
            
            <div class="input-box" >
                <label>Full Name</label>
                <input type="text" placeholder="Enter full name" name="fbname" id="fbname" >
            </div>
            
            <div class="input-box" >
                <label>Phone Number (without "-")</label>
                <input type="text" placeholder="Enter phone number" name="telNo" id="telNo" >
                </div>    
                
            <div class="input-box">
                <label>Open Hour</label>
                <input type="time" placeholder="Enter pick up date" name="hour" id="hour" >
            </div>
                
            <div class="input-box">
                <label>Email</label>
                <input type="text" placeholder="Enter email"  name="email" id="email" >
            </div>
            
            <div class="input-box" >
                <label>Address</label>
                <input type="text" placeholder="Enter street address" name="address" id="address" >
            </div>
            
            <div class="input-box">
                <label>QOH</label>
                <input type="number" name="QOH" id="QOH">
            </div>
            
    
            
            <button>Submit</button>
            
            
        </form>
            <a href="fb.php?adminID=<?php echo $adminID ?>"><button style="padding:0.5rem; border-radius:5px; border:none; font-size:15px; background-color:red; color:white; margin-top:0.7rem; margin-left:18.3rem;">Take Me Back !</button></a>
            
    </section>
</html>