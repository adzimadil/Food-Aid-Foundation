<?php
$adminID=$_GET['adminID'];

session_start();

$_SESSION['adminID']=$adminID;


$servername = "localhost";
$username = "root";
$password = "";
$dbname = "fadatabase";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection

if (!$conn) {
 die("Connection failed: " . mysqli_connect_error());
}

$per_page_record = 4;  

if (isset($_GET["page"])) {    
     $page  = $_GET["page"];    
    }    
else {    
     $page=1;    
    } 
 
 $start_from = ($page-1) * $per_page_record;     
   
 $sql="SELECT * FROM tblbank";
 $result=mysqli_query ($conn, $sql); 

 $query = "SELECT * FROM tblbank LIMIT $start_from, $per_page_record";   
 $rs_result = mysqli_query ($conn, $query);  

$sql2="SELECT * FROM tbladmin WHERE adminID='$adminID'";
//echo $sql2
$sql2_result = mysqli_query ($conn, $sql2); 


?>

<!DOCTYPE html>

<html lang="en">
    
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <title>Food Aid Foundation</title>
    
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
    
    <link rel ="stylesheet" href="./style3.css">
     <style>   
      .inline{   
            display: inline-block;   
            float: right;   
            margin-right: 37rem; 
            margin-top: 5rem;
            
        }   
         
        .inline input{   
            height: 45px;   
            background: none;
            margin-top: -4.2rem;
            margin-left: -3rem;
            position: absolute;
            color: black;
            z-index: 350;
     
        } 
         
    .pagination {   
        display: inline-block; 
        margin-left: 50rem;
        padding-right: 5rem;
    }   
    .pagination a {   
        font-weight:bold;   
        font-size:15px;   
        color: black;   
        float: left;   
        padding: 8px 16px;   
        text-decoration: none;   
        border:1px solid black; 
        border-radius: 2px;
    
    }   
    .pagination a.active {   
            background-color: var(--color-light);   
    }   
    .pagination a:hover:not(.active) {   
        background-color: darkseagreen;   
    }   
        </style>   
    
</head>

<body>
    <div class="cotainer">
           <aside>
         <div class="top">
                <div class="logo">
                    <img src="food_aid.png">
                    <h1 style="color: #008D52">Food Aid</h1>
                    <h4>Foundation</h4>
                </div>
                
                <div class="text">
                   <h3 style="font-size: 20px;">Welcome <b style="color: #008D52;">
                       <?php if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true) { 
                            while($row=mysqli_fetch_assoc($sql2_result)){echo $row["name"];
                             $adminID= $row["adminID"];}
                        } 
                       ?>
                </b> !</h3>
                </div>
            </div>
            
             <div class="sidebar">
                
                 
                <a href="fd.php?adminID=<?php echo $adminID ?>">
                   <span class="material-symbols-outlined">volunteer_activism</span>
                    <h3>Request</h3>
                </a>
                <br> 
                 <a href="fb.php?adminID=<?php echo $adminID ?>">
                   <span class="material-symbols-outlined">food_bank</span>
                    <h3>Food Bank</h3>
                 </a>
                <br>
                 <a href="volunteer.php?adminID=<?php echo $adminID ?>">
                   <span class="material-symbols-outlined">groups</span>
                    <h3>Volunteer</h3>
                </a>
                <br>
                <a href="cash_donation.php?adminID=<?php echo $adminID ?>">
                   <span class="material-symbols-outlined">savings</span>
                    <h3>Cash</h3>
                </a>
                <br>
                <a href="logout.php">
                   <span class="material-symbols-outlined">logout</span>
                    <h3>Log Out</h3>
                </a>
            </div>
   
         </aside>
        
        <main>
            <div class="activity">
                <div class="upper-small">
                    <form action="fbSearch.php?adminID=<?php echo $adminID ?>" method="POST">

                    <input type="search" name="search" placeholder="Quick Search">
                    </form>
                    
                                 <form action="fbSort.php?adminID=<?php echo $adminID ?>" method="POST" class="cdForm" style="margin-left:-42rem; margin-top:-1rem;"> 
                    <select name="sort" style="position: absolute;
    margin-top: -2rem;
    padding: 0.5rem;
    width: 7%;
    color:white;
    border-radius: 10px;
    background: var(--color-light);
    font-size: 13px; position:absolute;">
                        <option value="" selected="selected">Any Order</option>

                           <optgroup label="Sort by Location">
                            <option value="USJ">USJ area</option>
                            <option value="Sunway">Sunway area</option>
                            <option value="SS">SS area</option>
                        </optgroup>
                    </select>
                    <input type="submit" name="search" value="Sort" style="padding: 7px; border:none; background: none; color:var(--color-dark); margin-left:9rem; margin-top:-1.7rem; position:absolute;">
                </form>
                </div>
            <table>
                <thead>
                    <tr>
                        <th></th>
                        <th>Food Bank ID</th>
                        <th>Name</th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th>Delete</th>
                    </tr>
                </thead>
                <tbody>
                    
    <?php 
        if (mysqli_num_rows($result) > 0) {
                     
            $x=0;
            $arrID=array();
            $arrName=array();
                        
            while($row=mysqli_fetch_assoc($rs_result)) {
    ?>
                    
            <tr>     
            <td><?php echo $row["no"]; ?></td>     
            <td><?php echo $row["fbID"]; ?></td>   
            <td><?php echo $row["name"]; ?></td>   
            <?php 
            echo '<td><span class="material-symbols-outlined" onclick="myFunc1('.$x.')">overview</span></td>';
  
            echo '<td><span class="material-symbols-outlined" onclick="myFunc2('.$x.')">perm_media</span></td>';
     
            echo '<td><a href =fbEdit.php?fbID='. $row['fbID'].'><span class="material-symbols-outlined">edit</span></a></td>';
     
     
            echo '<td><a href =fbDelete.php?fbID='. $row['fbID'].'><span class="material-symbols-outlined">close</span></a></td>'; ?>
            </tr>  
        
        <?php 
                    
  $arrID[] = $row['fbID'];
  $arrName[] = $row['name'];
  $arrAddress[] = $row['address'];
  $arrOpen[] = $row['openHour'];
  $arrTel[] = $row['telNo'];
  $arrEmail[] = $row['email'];
  $arrQOH[] = $row['QOH'];
  $arrImg[] = $row['image'];
  $x++;  
            }
        } ?>
                                  
            <tr><td colspan=8><a href="fbAdd.php?adminID=<?php echo $adminID ?>" style=color:var(--color-light)>Add Record</a></td></tr>
            </tbody>            
            </table>
            </div>
            
    			<div>
              <?php
           
                
 if (count($arrID) > 0) {
    for($i=0;$i<count($arrID);$i++){
	?>
			<div class="detail" id="myDetail<?=$i?>" style="display:none;">
                <h1 class="text-uppercase" style="font-size:20px; margin-bottom:0.3rem;">DETAILS</h1><hr style="border-top: black solid 2px;" />
                
                    <h1 class="text-uppercase" style="margin-top:1rem;"><?=$arrID[$i]?></h1>
                    <h1 class="text-uppercase"><?=$arrName[$i]?></h1>
                
                <div class="smalltext">
                    <h4>Address : <?=$arrAddress[$i]?></h4><br>
                    <h4>Opening Hour : <?=$arrOpen[$i]?> A.M.</h4><br>
                    <h4>Tel No : <?php echo"$arrTel[$i]"?></h4><br>
                    <h4>Email : <?=$arrEmail[$i]?></h4><br>
                </div> 
                        
                        
                    <p class="small-text" style="margin-bottom: 1rem; margin-top: 2rem;">Inventory Overview</p>
                    <hr style="border-top: var(--color-light) dashed 1.5px;" />

                <div class="content">   
                    <h3>Quantity On Hand </h3>
                    <h3><?=$arrQOH[$i]?></h3>
                </div>
                
                     <div class="detail-nav">
                        <button onclick="myCancel(<?=$i?>)">Close</button>
                    </div>
                     
                </div> 	
	
	
	<?php
		
	}
 }                     
 

            ?>
            
            <?php
           
                
 if (count($arrID) > 0) {
    for($i=0;$i<count($arrID);$i++){
	?>
			<div class="detail" id="myDetail2<?=$i?>" style="display:none;">
                <h1 class="text-uppercase" style="font-size:20px; margin-bottom:0.3rem;"><?=$arrName[$i]?></h1><hr style="border-top: black solid 2px; margin-bottom:1.3rem;" />
                
              <p> 
	               <img src="<?=$arrImg[$i]?>" width="100px" > <br>
	         </p>
                <button style="background-color:var(--color-background); margin-top:1.2rem; width:25%;transform: translate(105%,-50%); font-size:10px; height:35px;  box-shadow: 0 0 5px rgba(4,3.5,8,0.3);"><?php echo '<a href =fbImage.php?fbID='. $arrID[$i] .'>Change/Upload Image</a>';?> </button>
                    <div class="detail-nav">
                        <button onclick="myCancel2(<?=$i?>)" style="margin-top:5rem;">Close</button>
                    </div> 
                </div> 	
	
	
	<?php
		
	}
 }                     
 
            ?>
            
            
            </div>
            
                
    <div class="pagination">    
      <?php  
        $query = "SELECT COUNT(*) FROM tblbank";     
        $rs_result = mysqli_query($conn, $query);     
        $row = mysqli_fetch_row($rs_result);     
        $total_records = $row[0];     
          
    echo "</br>";     
        // Number of pages required.   
        $total_pages = ceil($total_records / $per_page_record);     
        $pagLink = "";       
      
        if($page>=2){   
            echo "<a href='fb.php?adminID=".($adminID)."& page=".($page-1)."'>  Prev </a>";   
        }       
                   
        for ($i=1; $i<=$total_pages; $i++) {   
          if ($i == $page) {   
              $pagLink .= "<a class = 'active' href='fb.php?adminID=".($adminID)."& page="  
                                                .$i."'>".$i." </a>";   
          }               
          else  {   
              $pagLink .= "<a href='fb.php?adminID=".($adminID)."& page=".$i."'>   
                                                ".$i." </a>";     
          }   
        };     
        echo $pagLink;   
  
        if($page<$total_pages){   
            echo "<a href='fb.php?adminID=".($adminID)."& page=".($page+1)."'>  Next </a>";   
        }   
  
      ?>    
      </div>   
           
    
 <!----      
    <div class="inline" >   
      <input id="page" type="number" min="1" max="<?php echo $total_pages?>"   
      placeholder="<?php echo $page."/".$total_pages; ?>" required>   
      <button onClick="go2Page();" style="margin-top: -3.5rem; margin-left:-1.3rem; float:right; padding: 4px; width:30px; border-radius:2px; ">Go</button>   
     </div>  
                
 -->         
        </main>
    </div>
    
      <script> 
          /*
    function go2Page()   
    {   
        var adminID = <?php echo $adminID ?>;
        var page = document.getElementById("page").value;   
        page = ((page><?php echo $total_pages; ?>)?<?php echo $total_pages; ?>:((page<1)?1:page));   
        window.location.href = "fb.php"+ "?page="+page+"&adminID="+ adminID;   
    }  
    */              
    function myFunc1(i){
            var j="myDetail"+i;
            document.getElementById(j).style.display = "block";
        }
        
          function myFunc2(i){
            var j="myDetail2"+i;
            document.getElementById(j).style.display = "block";
        }
        
        function myCancel(i){
			var j="myDetail"+i;
            document.getElementById(j).style.display = "none";
        }
        
        function myCancel2(i){
			var j="myDetail2"+i;
            document.getElementById(j).style.display = "none";
        }
  </script> 
    
</body>
    <?php mysqli_close($conn); ?>
</html>
