<?php
session_start();

//set-up
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "fadatabase";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check connection
if (!$conn) {
  $conn = mysqli_connect($servername, $username, $password, $dbname);
}

echo $sql;

//from previous lesson
$gender = (!empty($_POST["gender"]))?$_POST["gender"]:"";


    if(empty($_POST["name"]))
		echo "<script>alert('Fill in name');</script>";
	else
		$name=$_POST["name"];

	if(empty($_POST["tel"]))	
		echo "<script>alert('Fill in telephone number');</script>";
	else
		$telNo=$_POST["tel"];

	if(empty($_POST["email"]))	
		echo "<script>alert('Fill in email');</script>";
	else
		$email=$_POST["email"];

    if(empty($_POST["id"]))	
		echo "<script>alert('Fill in id');</script>";
	else
		$id=$_POST["id"];

    if(empty($_POST["pwd"]))	
		echo "<script>alert('Fill in password');</script>";
	else
		$password=$_POST["pwd"];

$salt="fadatabase";
$pwd=sha1($password.$salt);


$sql = "INSERT INTO tbladmin (adminID, pwd, gender, name, 
telNo, email) VALUES
('$id','$pwd','$gender', '$name','$telNo','$email');";

$sql2= "SELECT * FROM tbladmin;";

$result = mysqli_query($conn, $sql2);

$rowcount = mysqli_num_rows($result);

if (preg_match("/^[A-Z]{2}[0-9]{4}$/",$id)){
    if (preg_match("/^[0-9]{2,3}-[0-9]{7,}$/",$telNo)){
        if (preg_match("/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,3}$/",$email))
        {
           if (mysqli_query($conn, $sql)) {
               $_SESSION['logged_in'] = true;
                header("Location:fb.php?adminID=$id");
            }
        }
        else 
         echo "<script>window.location.href='signUp.php'; alert('Wrong email format');</script>";
    }
    else
    echo "<script>window.location.href='signUp.php'; alert('Wrong telephone number format');</script>";
}
else 
echo "<script>window.location.href='signUp.php'; alert('Wrong id format');</script>"; 


mysqli_close($conn);


?>


