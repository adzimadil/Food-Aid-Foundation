<?php
session_start();

$adminID=$_SESSION['adminID'];
//from previous lesson
$name= (!empty($_POST["name"]))?$_POST["name"]:"";
$tel = isset ($_POST["tel"])?$_POST["tel"]:"-";
$date = (!empty($_POST["date"]))?$_POST["date"]:"";
$address = (!empty($_POST["address"]))?$_POST["address"]:"";
$time = (!empty($_POST["time"]))?$_POST["time"]:"00:00:00";
$qoh = (!empty($_POST["quantity"]))?$_POST["quantity"]:"0";
$stat = (!empty($_POST["stat"]))?$_POST["stat"]:"0";

//set-up
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "fadatabase";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check connection
if (!$conn) {
  $conn = mysqli_connect($servername, $username, $password, $dbname);
}

$sql = "INSERT INTO tbldonation (name, phoneNum, pickDate, pickTime, 
address, totalItems, status) VALUES
('$name','$tel','$date', '$time','$address','$qoh', '$stat');";

echo $sql;

if (mysqli_query($conn, $sql)) {
     echo "<script>
window.location.href='fd.php?adminID=" .$adminID ."';
alert('New record has been added !');
</script>";
} else {
  echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

mysqli_close($conn);


?>