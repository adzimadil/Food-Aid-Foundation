<?php
session_start();

$adminID=$_SESSION['adminID'];
//from previous lesson
$name= (!empty($_POST["fbname"]))?$_POST["fbname"]:"";
$id = isset($_POST["fbID"])?$_POST["fbID"]:"";
$email= (!empty($_POST["email"]))?$_POST["email"]:"-";
$tel = isset ($_POST["telNo"])?$_POST["telNo"]:"-";

$address = (!empty($_POST["address"]))?$_POST["address"]:"";
$hour = (!empty($_POST["hour"]))?$_POST["hour"]:"00:00:00";
$qoh = (!empty($_POST["QOH"]))?$_POST["QOH"]:"0";

//set-up
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "fadatabase";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}

$sql = "INSERT INTO tblbank (fbID, name, address, email, telNo, 
QOH, openHour) VALUES
('$id','$name','$address','$email', '$tel','$qoh','$hour');";

echo $sql;


if (mysqli_query($conn, $sql)) {
   echo "<script>
window.location.href='fb.php?adminID=" .$adminID ."';
alert('New record has been added !');
</script>";
} else {
  echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

mysqli_close($conn);



?>

