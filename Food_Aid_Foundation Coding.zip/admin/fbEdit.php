<?php
session_start();

$adminID=$_SESSION['adminID'];

$id= isset($_GET["fbID"])?$_GET["fbID"]:"";

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "fadatabase";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}

$sql = "SELECT * FROM tblbank WHERE fbID='$id';";


$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
  // output data of each row
 

  while($row = mysqli_fetch_assoc($result)) {
	$id=$row["fbID"]; 
	$name=$row["name"];
	$address=$row["address"];
    $email=$row["email"];
	$tel=$row["telNo"];
	$qoh = $row["QOH"];
	$hour = $row["openHour"];
  }
} 
mysqli_close($conn);
?>


<!DOCTYPE HTML>
<html>
    <head>   <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <title>Food Aid Foundation</title>
    
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
    <link rel ="stylesheet" href="fdAddStyle.css">
    
    </head>
        <section class="container">
    <header>Food Bank edit information form</header>
        <form action="fbEdit2.php" method="POST" class="form">
            
            <div class="input-box" >
                <label>ID</label>
                <input type="text" placeholder="Enter ID" name="fbID" id="fbID" maxlength="5" value="<?php echo $id?>">
            </div>
            
            <div class="input-box" >
                <label>Full Name</label>
                <input type="text" placeholder="Enter full name" name="fbname" id="fbname" value="<?php echo $name?>">
            </div>
            
            <div class="input-box" >
                <label>Phone Number (without "-")</label>
                <input type="text" placeholder="Enter phone number" name="telNo" id="telNo" value="<?php echo $tel?>" >
                </div>    
                
            <div class="input-box">
                <label>Open Hour</label>
                <input type="time" placeholder="Enter pick up date" name="hour" id="hour" value="<?php echo $hour?>" >
            </div>
                
            <div class="input-box">
                <label>Email</label>
                <input type="text" placeholder="Enter email"  name="email" id="email" value="<?php echo $email?>">
            </div>
            
            <div class="input-box" >
                <label>Address</label>
                <input type="text" placeholder="Enter street address" name="address" id="address" value="<?php echo $address?>" >
            </div>
            
            <div class="input-box">
                <label>QOH</label>
                <input type="number" name="QOH" id="QOH" value="<?php echo $qoh?>">
            </div>
            <button>Submit</button>
        </form>
            <a href="fb.php?adminID=<?php echo $adminID ?>"><button style="padding:0.5rem; border-radius:5px; border:none; font-size:15px; background-color:red; color:white; margin-top:0.7rem; margin-left:18.3rem;">Take Me Back !</button></a>
    </section>
</html>