<?php
session_start();

$adminID=$_SESSION['adminID'];

//from previous lesson
$id = isset($_POST["requestID"])?$_POST["requestID"]:"";
$name= (!empty($_POST["name"]))?$_POST["name"]:"";
$tel = isset ($_POST["tel"])?$_POST["tel"]:"-";
$date = (!empty($_POST["date"]))?$_POST["date"]:"";
$address = (!empty($_POST["address"]))?$_POST["address"]:"";
$time = (!empty($_POST["time"]))?$_POST["time"]:"00:00:00";
$qoh = (!empty($_POST["quantity"]))?$_POST["quantity"]:"0";
$stat = (!empty($_POST["stat"]))?$_POST["stat"]:"0";


$servername = "localhost";
$username = "root";
$password = "";
$dbname = "fadatabase";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}

$sql = "UPDATE tbldonation SET
name='$name',
phoneNum='$tel',
pickTime='$time',
address='$address',
pickDate='$date',
totalItems='$qoh',
status='$stat'
WHERE requestID=$id;";

//echo $sql;

if (mysqli_query($conn, $sql)) {
   echo "<script>
window.location.href='fd.php?adminID=" .$adminID ."';
alert('The record has been successfully updated. ');
</script>";
} else {
  echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

mysqli_close($conn);


?>