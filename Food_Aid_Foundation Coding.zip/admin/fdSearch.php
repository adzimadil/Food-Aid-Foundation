<?php
$adminID=$_GET['adminID'];

session_start();

$search = $_POST['search'];

$servername = "localhost";
$username = "root";
$password = "";
$db = "fadatabase";

$conn = new mysqli($servername, $username, $password, $db);

if ($conn->connect_error){
	die("Connection failed: ". $conn->connect_error);
}

$sql = "SELECT * FROM tbldonation WHERE CONCAT(address,name,pickDate,pickTime,status,requestID,phoneNum) LIKE '%$search%' ORDER BY name ASC;";

//echo $sql;

$result = $conn->query($sql);

$sql2="SELECT * FROM tbladmin WHERE adminID='$adminID'";
//echo $sql2;
$sql2_result = mysqli_query ($conn, $sql2); 


?>

<!DOCTYPE html>

<html lang="en">
    
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <title>Food Aid Foundation</title>
    
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
    
    <link rel ="stylesheet" href="./style3.css">
</head>

<body>
    <div class="cotainer">
           <aside>
         <div class="top">
                <div class="logo">
                    <img src="food_aid.png">
                    <h1 style="color: #008D52">Food Aid</h1>
                    <h4>Foundation</h4>
                </div>
                
                <div class="text">
                   <h3 style="font-size: 20px;">Welcome <b style="color: #008D52"><?php  while($row=mysqli_fetch_assoc($sql2_result)){echo $row["name"];} ?></b> !</h3>
                </div>
             
            </div>
             <div class="sidebar">
               <a href="fd.php?adminID=<?php echo $adminID ?>">
                   <span class="material-symbols-outlined">volunteer_activism</span>
                    <h3>Request</h3>
                </a>
                <br>
                 <a href="fb.php?adminID=<?php echo $adminID ?>">
                   <span class="material-symbols-outlined">food_bank</span>
                    <h3>Food Bank</h3>
                </a>
                <br>
                 <a href="volunteer.php?adminID=<?php echo $adminID ?>">
                   <span class="material-symbols-outlined">groups</span>
                    <h3>Volunteer</h3>
                </a>
                <br>
                <a href="cash_donation.php?adminID=<?php echo $adminID ?>">
                   <span class="material-symbols-outlined">savings</span>
                    <h3>Cash</h3>
                </a>
                <br>
                <a href="logout.php">
                   <span class="material-symbols-outlined">logout</span>
                    <h3>Log Out</h3>
                </a>
            </div>
         </aside>
        
        <main>
            <div class="activity">
                <div class="upper-small">
                    <form action="fdSearch.php?adminID=<?php echo $adminID ?>" method="POST">
             

                    <input type="search" name="search" placeholder="Quick Search....... " value="<?php echo $search ?>">
                    </form>
                </div>
            <table>
                <thead>
                    <tr>
                        <th>Request ID</th>
                        <th>Name</th>
                        <th>Address</th>
                        <th>Time & Date</th>
                        <th>Tel No</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
<?php
if ($result->num_rows > 0){
while($row = $result->fetch_assoc() ){
    echo"<tr>";
    echo "<td>" . $row['requestID'] . "</td>";
    echo "<td>" . $row['name'] . "</td>";
    echo "<td>" . $row['address'] . "</td>";
    echo "<td>" . $row['pickTime'] . "A.M. ". $row['pickDate'] . "</td>";
    echo "<td> " . $row['phoneNum'] . "</td>";
    echo "<td>" . $row['status'] . "</td>";
    echo "</tr>";
}
} else {
	echo "0 records";
}
  


?>
                    <tr><td colspan=8><a href="fd.php?adminID=<?php echo $adminID ?>" style=color:var(--color-light)>Go Back</a></td></tr>
                     </tbody>
                </table>
                
                
            </div>
        </main>
        </div>
    </body>
    <?php $conn->close(); ?>
</html>
                

