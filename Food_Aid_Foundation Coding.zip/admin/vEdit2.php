<?php
session_start();

$adminID=$_SESSION['adminID'];

//from previous lesson
$id = isset($_POST["volunteerID"])?$_POST["volunteerID"]:"";
$name= (!empty($_POST["name"]))?$_POST["name"]:"";
$age = isset($_POST["age"])?$_POST["age"]:"";
$email= (!empty($_POST["email"]))?$_POST["email"]:"-";
$tel = isset ($_POST["telNo"])?$_POST["telNo"]:"-";
$address = (!empty($_POST["location"]))?$_POST["location"]:"";
$hour = (!empty($_POST["time"]))?$_POST["time"]:"00:00:00";
$date = (!empty($_POST["date"]))?$_POST["date"]:"-";
$gender = (!empty($_POST["gender"]))?$_POST["gender"]:"-";
$stat = (!empty($_POST["stat"]))?$_POST["stat"]:"-";

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "fadatabase";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}

$sql = "UPDATE tblvolunteer SET

name='$name',
email='$email',
telNo='$tel',
location='$address',
time='$hour',
date='$date',
status='$stat',
gender='$gender',
time='$hour'

WHERE volunteerID=$id;";

echo $sql;

if (mysqli_query($conn, $sql)) {
  echo "<script>
window.location.href='volunteer.php?adminID=" .$adminID ."';
alert('The record has been successfully updated. ');
</script>";
} else {
  echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

mysqli_close($conn);


?>