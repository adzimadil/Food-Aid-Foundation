<?php
session_start();

$adminID=$_SESSION['adminID'];

function recordUploadData($picName){
    $id= isset($_GET["fbID"])?$_GET["fbID"]:"";
	//set-up
	$servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "fadatabase";
	// Create connection
	$conn = mysqli_connect($servername, $username, $password, $dbname);
	// Check connection
	if (!$conn) {
	  die("Connection failed: " . mysqli_connect_error());
	}
	$sql="UPDATE tblbank SET image='$picName' WHERE fbID='$id';";
    //echo $sql;
	if(mysqli_query($conn,$sql)){
		echo "Record added sucessfully. ";	
	}else{
		echo "Error: " . $sql . "<br>" . mysqli_error($conn);
	}
	mysqli_close($conn);
}









?>

<!DOCTYPE html>
<html>
    <link rel ="stylesheet" href="fdAddStyle.css">

<body>

<section class="container">

<form action=" " method="post" 
enctype="multipart/form-data">
    <h1>Foodbank Image Form</h1>
  Select image to upload:
    <div>
  <input type="file" name="fileUpload" id="fileUpload">
  <input type="submit" value="Upload File" name="submit">
    </div>
    
    <?php
        if (isset($_POST['submit']) && $_POST['submit'] == 'Upload File')
{
  if (isset($_FILES['fileUpload']) && $_FILES['fileUpload']['error'] === UPLOAD_ERR_OK)
  {
    // get details of the uploaded file
    $fileTmpPath = $_FILES['fileUpload']['tmp_name'];
    $fileName = $_FILES['fileUpload']['name'];
    $fileSize = $_FILES['fileUpload']['size'];
    $fileType = $_FILES['fileUpload']['type'];
    $fileNameCmps = explode(".", $fileName);
    $fileExtension = strtolower(end($fileNameCmps));
	//echo  "$fileTmpPath - $fileName - $fileSize - $fileType - $fileExtension";
 
    // sanitize file-name
    $newFileName = md5(time() . $fileName) . '.' . $fileExtension;
 
    // check if file has one of the following extensions
    $allowedfileExtensions = array('jpg', 'gif', 'png', 'bmp');
 
    if (in_array($fileExtension, $allowedfileExtensions))
    {
      // directory in which the uploaded file will be moved
      $uploadFileDir = "image/";
      //$dest_path = $uploadFileDir . $fileName;
	  $dest_path = $uploadFileDir . $newFileName;
 
      if(move_uploaded_file($fileTmpPath,$dest_path)) 
      {
         echo "<script>
window.location.href='fb.php?adminID=" .$adminID ."';
alert('Image succesfully uploaded!');
</script>";
		recordUploadData($dest_path);
      }
      else
      {
        $message = 'There was some error moving the file to upload directory. Please make sure the upload directory is writable by web server.';
      }
    }
    else
    {
      $message = 'Upload failed. Allowed file types: ' . implode(',', $allowedfileExtensions);
    }
	
  }
  else
  {
    $message = 'There is some error in the file upload. Please check the following error.<br>';
    $message .= 'Error:' . $_FILES['fileUpload']['error'];
  }
  echo  $message;

}
    
    ?>
    
    
</form>
    <a href="fb.php?adminID=<?php echo $adminID ?>"><button style="padding:0.5rem; border-radius:5px; border:none; font-size:15px; background-color:red; color:white; margin-top:0.7rem; margin-left:18.3rem;">Take Me Back !</button></a>
    </section>

</body>
</html>