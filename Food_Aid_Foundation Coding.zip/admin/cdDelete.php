<?php
session_start();

$adminID=$_SESSION['adminID'];

//from previous lesson
$id= isset($_GET['transID'])?$_GET['transID']:"";
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "fadatabase";
// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}
$sql = "DELETE FROM tblcash WHERE transID=$id;";


if (mysqli_query($conn,$sql)) {
    echo "<script>
window.location.href='cash_donation.php?adminID=" .$adminID ."';
alert('The record has been deleted.');
</script>";
    
}else {
  echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}
mysqli_close($conn);
?>