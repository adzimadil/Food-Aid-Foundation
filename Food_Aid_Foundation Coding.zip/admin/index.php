
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <title>Food Aid Foundation</title>
    
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
    
    <link rel ="stylesheet" href="style2.css">
</head>
    
<body>
    <div class="container">
        <div class="logo">
            <img src="food_aid.png">
            <h1>Food Aid</h1>
            <h4>Foundation</h4>
        </div>
        <div class="login_form">
            <form method="POST" action="validate.php">
                <label for="adminID">Admin ID</label>
                <input type="text" placeholder="Username" id="adminID" name="adminID" maxlength="8">

                <label for="pwd">Password</label>
                <input type="password" placeholder="Password" id="pwd" name="pwd">

                <input type="submit" id="submit" name="submit">
                New admin ? Sign Up <a href="signUp.php">Here</a> ! 
            </form>
        </div>
    </div>
</body>
    
    
</html>