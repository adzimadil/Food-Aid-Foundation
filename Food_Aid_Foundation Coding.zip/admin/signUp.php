<!DOCTYPE HTML>
<html>
    <head>   <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <title>Food Aid Foundation</title>
    
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
    <link rel ="stylesheet" href="signUpStyle.css">
    
    </head>
        <section class="container">
        <div class="logo">
            <img src="food_aid.png">
            <h1>Food Aid</h1>
            <h4 >Foundation</h4>
        </div>
            
        <form action="signUp2.php" method="POST" class="form">
            <h2>Admin Sign Up form</h2>
            <div class="input-box" >
                <label>Admin ID</label>
                <input type="text" placeholder="Enter admin ID" name="id" id="id" >
            </div>
            
            <div class="input-box" >
                <label>Password</label>
                <input type="password" placeholder="Enter password" name="pwd" id="pwd" >
            </div>
            
              <div class="input-box" >
                <label>Name</label>
                <input type="text" placeholder="Enter full name" name="name" id="name" >
            </div>
            
              <div class="input-box" >
                <label>Email</label>
                <input type="text" placeholder="Enter email address" name="email" id="email" >
            </div>
            
            <div class="input-box" style="margin-bottom:2rem;">
                <label>Phone Number</label>
                <input type="text" placeholder="Enter phone number" name="tel" id="tel" >
            </div>  
            
           
               Gender : 
                 <input type="radio" id="female" name="gender" value="Female">
                 <label for="female">Female</label>
                 <input type="radio" id="male" name="gender" value="Male">
                 <label for="female">Male</label>
                
            
            <button>Submit</button>
        </form>
            <input type="checkbox" name="term" style="margin-top:1rem;">
           <label for="terms">I read and understand the <a href="#">Terms & Agreement</a></label>
    </section>
</html>