<?php

session_start();

$_SESSION = array();

session_destroy();

echo "<script>alert('Logout Successful!'); window.location.href = 'index.php';</script>";

header("Location: index.php");

exit;
?>