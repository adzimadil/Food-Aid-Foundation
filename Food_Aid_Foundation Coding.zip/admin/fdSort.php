<?php
$adminID=$_GET['adminID'];

session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "fadatabase";

$conn = mysqli_connect($servername, $username, $password, $dbname);

$sql2="SELECT * FROM tbladmin WHERE adminID='$adminID'";
//echo $sql2;
$sql2_result = mysqli_query ($conn, $sql2); 


if(isset($_POST['search']))
{
    $valueToSearch = $_POST['sort'];
  
    $query = "SELECT * FROM `tbldonation` WHERE CONCAT(address,status) LIKE '%".$valueToSearch."%'";
    $search_result = filterTable($query);
    
}
 else {
    $query = "SELECT * FROM `tbldonation`";
    $search_result = filterTable($query);
}


function filterTable($query)
{
    $connect = mysqli_connect("localhost", "root", "", "fadatabase");
    $filter_Result = mysqli_query($connect, $query);
    return $filter_Result;
}

 

?>
<!DOCTYPE html>

<html lang="en">
    
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <title>Food Aid Foundation</title>
    
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
    
    <link rel ="stylesheet" href="./style3.css">
</head>

<body>
    <div class="cotainer">
           <aside>
         <div class="top">
                <div class="logo">
                    <img src="food_aid.png">
                    <h1 style="color: #008D52">Food Aid</h1>
                    <h4>Foundation</h4>
                </div>
            <div class="text">
                   <h3 style="font-size: 20px;">Welcome <b style="color: #008D52">  <?php  while($row=mysqli_fetch_assoc($sql2_result)){echo $row["name"];} ?></b> !</h3>
                </div>
            </div>
                
            
              <div class="sidebar">
               <a href="fd.php?adminID=<?php echo $adminID ?>">
                   <span class="material-symbols-outlined">volunteer_activism</span>
                    <h3>Request</h3>
                </a>
                <br>
                 <a href="fb.php?adminID=<?php echo $adminID ?>">
                   <span class="material-symbols-outlined">food_bank</span>
                    <h3>Food Bank</h3>
                </a>
                <br>
                 <a href="volunteer.php?adminID=<?php echo $adminID ?>">
                   <span class="material-symbols-outlined">groups</span>
                    <h3>Volunteer</h3>
                </a>
                <br>
                <a href="cash_donation.php?adminID=<?php echo $adminID ?>">
                   <span class="material-symbols-outlined">savings</span>
                    <h3>Cash</h3>
                </a>
                <br>
                <a href="logout.php">
                   <span class="material-symbols-outlined">logout</span>
                    <h3>Log Out</h3>
                </a>
            </div>
         </aside>
        
        <main>
            <div class="activity">

            <table style="margin-top:3rem;">
                <thead>
                    <tr>
                        <th>Request ID</th>
                        <th>Requested Date</th>
                        <th>Requested By</th>
                        <th>Status</th>
                        <th>Address</th>
                    </tr>
                </thead>
                <tbody>

                <?php while($row = mysqli_fetch_array($search_result)):?>
                <tr>
                    <td><?php echo $row['requestID'];?></td>
                    <td><?php echo $row['pickDate'];?></td>
                    <td><?php echo $row['name'];?></td>
                    <td><?php echo $row['status'];?></td>
                    <td><?php echo $row['address'];?></td>
                </tr>
                
            
                <?php endwhile;?>
                      <tr><td colspan="5"><a href=fd.php?adminID=<?php echo $adminID ?>>Go Back</a></td></tr>
                </tbody>
            </table>
                      <form action="fdSort.php?adminID=<?php echo $adminID ?>" method="POST" class="cdForm" style="margin-left:-77rem; margin-top:-1rem;"> 
                 
                    <select name="sort" style="position: absolute;
  margin-top: -2rem;
    padding: 0.5rem;
    width: 7%;
    color:white;
    border-radius: 10px;
    background: var(--color-light);
    font-size: 13px; position:absolute;">
                        <option value="" selected="selected"><?php echo $valueToSearch ?></option>
                        <optgroup label="Sort by Status">
                            <option value="pending">Pending</option>
                            <option value="verifying">Verifying</option>
                            <option value="complete">Completed</option>
                            <option value="reject">Rejected</option>
                        </optgroup>
                        
                        
                           <optgroup label="Sort by Location">
                            <option value="USJ">USJ area</option>
                            <option value="Sunway">Sunway area</option>
                            <option value="SS">SS area</option>
                        </optgroup>
                    </select>
                    <input type="submit" name="search" value="Sort" style="padding: 7px; border:none; background: none; color:var(--color-dark); margin-left:9rem; margin-top:-1.7rem; position:absolute;">
                        
                </form>
            </div>
        </main>
    </div>
    </body>
    <?php mysqli_close($conn); ?>
    
</html>

                