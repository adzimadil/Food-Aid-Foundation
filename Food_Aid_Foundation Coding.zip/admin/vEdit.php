<?php
session_start();

$adminID=$_SESSION['adminID'];

$id= isset($_GET["volunteerID"])?$_GET["volunteerID"]:"";

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "fadatabase";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}

$sql = "SELECT * FROM tblvolunteer WHERE volunteerID=$id;";

$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
  // output data of each row
 
  while($row = mysqli_fetch_assoc($result)) {
$id= $row["volunteerID"];
$name= $row["name"];
$tel = $row["telNo"];
$date = $row["date"];
$address = $row["location"];
$time = $row["time"];
$stat = $row["status"];
$gender = $row["gender"];
$age = $row["age"];
$email=$row["email"];
  }
} 


mysqli_close($conn);


?>

<!DOCTYPE HTML>
<html>
    <head>   <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <title>Food Aid Foundation</title>
    
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
    <link rel ="stylesheet" href="fdAddStyle.css">
    
    
    </head>
        <section class="container">
    <header>Volunteer information edit form</header>
        <form action="vEdit2.php" method="POST" class="form">
       
             <div class="input-box" >
                <label>ID</label>
                <input type="text" placeholder="Enter full name" name="volunteerID" id="volunteerID" value="<?=$id?>" >
            </div>
            
            <div class="input-box" >
                <label>Full Name</label>
                <input type="text" placeholder="Enter full name" name="name" id="name" value="<?=$name?>" >
            </div>
            
            <div class="input-box" >
                <label>Age:</label>
              <input type="text" id="age" name="age" required value="<?=$age?>"> 
                </div>    
      
            <div style="margin-top:2rem;">
                <label>Gender:</label>
                <input type="radio" name="gender" value="male" required <?php if($gender=="Male"){?>
    checked
                       <?php }?> >Male
                <input type="radio" name="gender" value="female" required <?php if($gender=="Female"){?>
    checked <?php }?>
    >Female
            </div>  
                
            <div class="input-box">
                <label>Email:</label>
                <input type="text" id="email" name="email" required value="<?=$email?>">
            </div>
            
            <div class="input-box" >
               <label>Phone Number:</label>
                <input type="text" id="phoneNo" name="phoneNo" required value="<?=$tel?>">
            </div>
            
            <div class="input-box" >
                <label>Status</label>
                <select name="stat" id="stat">
                   <option value="Verifying" <?php if ($stat=="Verifying"){?>
                       selected <?php } ?> >Verifying</option>
                    <option value="Completed"<?php if ($stat=="Completed"){?>
                       selected <?php } ?>>Completed</option>
                    <option value="Rejected" <?php if ($stat=="Rejected"){?>
                       selected <?php } ?>>Rejected</option>
                    <option value="Pending" <?php if ($stat=="Pending"){?>
                       selected <?php } ?>>Pending</option>
                </select>
            </div>
            
            <div class="input-box">
                <label>Volunteer Location:</label>
                <input type="text" id="location" name="location" required value="<?=$address?>">
            </div>
            
            <div class="input-box">
                <label>Time:</label>
    			<input type="time" id="time" name="time"  value="<?=$time?>">
            </div>
            
            <div class="input-box">
                <label>Date:</label>
    			<input type="date" id="date" name="date"  value="<?=$date?>">
            </div>
            
            <button type="submit">Submit</button>
        </form>
             <a href="volunteer.php?adminID=<?php echo $adminID ?>"><button style="padding:0.5rem; border-radius:5px; border:none; font-size:15px; background-color:red; color:white; margin-top:0.7rem; margin-left:18.3rem;">Take Me Back !</button></a>
    </section>
</html>