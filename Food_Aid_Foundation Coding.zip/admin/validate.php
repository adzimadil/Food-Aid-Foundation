<?php
session_start();

$id = empty($_POST["adminID"])?"":$_POST["adminID"];

$password = empty($_POST["pwd"])?"":$_POST["pwd"];
$salt= "fadatabase";
$pwd = sha1($password.$salt);

//set-up
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "fadatabase";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}
$sql = "SELECT * FROM tbladmin WHERE adminId='$id' and 
pwd='$pwd'";

echo $sql;

$result = mysqli_query($conn, $sql);
if(mysqli_num_rows($result)>0){
	while($row=mysqli_fetch_assoc($result)){
        
	if( ($pwd==$row["pwd"]) && ($id==$row["adminID"])){
        $_SESSION['logged_in'] = true;
		header("Location:fb.php?adminID={$row['adminID']}");}
    else {
	   echo "<script>
       window.location.href='index.php';
       alert('Invalid credential');</script>";}
    }
}




?>